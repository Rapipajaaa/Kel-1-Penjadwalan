<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;
use CodeIgniter\HTTP\ResponseInterface;

class AuthController extends BaseController
{
    public function index()
    {
        //
    }

    public function submit() 
    {
       // Ambil data dari form
       $username = $this->request->getPost('username');
       $password = $this->request->getPost('password');

       $model = new UserModel();

       $inputPass = $password;

       $hashedPassword = password_hash($inputPass, PASSWORD_DEFAULT);

       var_dump($password);

       // Siapkan data yang akan disimpan
       $data = [
           'username' => $username,
           'password' => $password, // Password yang sudah di-hash
           'login_time' => date('Y-m-d H:i:s') // Waktu login
       ];

    //    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

       // Insert data ke database
       $model->insert($data);  

        return view('welcome_message');
    }
}
